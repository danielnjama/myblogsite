from django.apps import AppConfig


class ForadminConfig(AppConfig):
    name = 'foradmin'
