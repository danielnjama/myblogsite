from django.apps import AppConfig


class ForcustomerConfig(AppConfig):
    name = 'forcustomer'
